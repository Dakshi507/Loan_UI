

export class ResponseApi{
        constructor(  
        public status:boolean,
        public msg:string,
        public values:any
           
        ) {
           
        }
    }