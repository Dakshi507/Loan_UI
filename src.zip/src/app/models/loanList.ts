export class LoanList{
    /**
     *
     */
    constructor(
       
        public Loannumber?:number,
        public  Propertyaddress?:string,
        public Loanamount?:number,
        public Loantype ?:string,
        public Loanterm ?:string,
        public Userid?:number,
       
    ) {
       
    }
}