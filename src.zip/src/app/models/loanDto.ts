export class LoanDto{
    /**
     *
     */
    constructor(

        public Userid?:number,
        public Loanid?:number,
        public Loannumber?:number,
        public  Propertyaddress?:string,
        public Loanamount?:number,
        public Loantype?:string,
        public Firstname ?:string,
        public Lastname ?:string,
        public Loanterm ?:string,

       
       
    ) {
       
    }
}